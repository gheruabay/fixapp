// open-app.js
// @ts-ignore
document.getElementById('app-logo').addEventListener('click', () => {
    window.open('index.html', '_self'); // Mở trang index.html của ứng dụng
});
